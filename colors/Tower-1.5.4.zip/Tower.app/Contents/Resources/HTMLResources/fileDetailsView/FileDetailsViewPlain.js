// The Cocoa GCCommitDetailsViewController is available as a JavaScript variable:
// window.CocoaController
// logging can be done with: CocoaController.log(CocoaController.displayedCommit.subject());

function showFileContent(contentString){
	$("#loadingMessageArea").hide();
	if(!contentString){
		// no preview available
		$("#contentArea").hide();
		$("#largeContentWarningArea").hide();
		$("#shadowContainer").show();
		$("#nothingToShowArea").show();
	}else{
		// show content
		$("#shadowContainer").hide();
		$("#nothingToShowArea").hide();
		$("#largeContentWarningArea").hide();
		$("#contentArea").show().html(contentString);
	}
}


/**
 Shows the "Large amount of data" warning area
 */
function showLargeContentWarning(){
	$('#loadingMessageArea').hide();
	$("#contentArea").hide();
	$("#nothingToShowArea").hide();
	$("#shadowContainer").show();
	$('#largeContentWarningArea').show();
}


/**
 As soon as page is loaded, starts to setup content
 */
$(function(){
//  CocoaController.log("Hello to Cocoa NSLog from JavaScript");  
  $('#loadLargeContentButton').mousedown(function(){
											$(this).addClass('pressed');
										 });
  $('#loadLargeContentButton, body').mouseup(function(){
												$('#loadLargeContentButton').removeClass('pressed');
											 });
  $('#loadLargeContentButton').click(function(){
										CocoaController.replaceContent();
									 });
  
});