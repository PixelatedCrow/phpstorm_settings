// The Cocoa GCCommitDetailsViewController is available as a JavaScript variable:
// window.CocoaController
// logging can be done with: CocoaController.log(CocoaController.displayedCommit.subject());

function showFileContent(contentString){
	// show content
	$("#submoduleSelectedMessage").html(contentString);
}


/**
 As soon as page is loaded, starts to setup content
 */
$(function(){
//  CocoaController.log("Hello to Cocoa NSLog from JavaScript");  
//  setupPage();
});